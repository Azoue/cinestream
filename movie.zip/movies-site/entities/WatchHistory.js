{
  "name": "WatchHistory",
  "type": "object",
  "properties": {
    "movie_id": {
      "type": "string",
      "description": "Reference to the movie"
    },
    "movie_title": {
      "type": "string",
      "description": "Cached movie title"
    },
    "movie_poster": {
      "type": "string",
      "description": "Cached poster URL"
    },
    "progress": {
      "type": "number",
      "default": 0,
      "description": "Watch progress in seconds"
    },
    "duration": {
      "type": "number",
      "default": 0,
      "description": "Total duration in seconds"
    },
    "completed": {
      "type": "boolean",
      "default": false,
      "description": "Whether the user finished watching"
    }
  },
  "required": [
    "movie_id"
  ]
}