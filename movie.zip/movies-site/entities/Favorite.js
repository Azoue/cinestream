{
  "name": "Favorite",
  "type": "object",
  "properties": {
    "movie_id": {
      "type": "string",
      "description": "Reference to the movie"
    },
    "movie_title": {
      "type": "string",
      "description": "Cached movie title for quick display"
    },
    "movie_poster": {
      "type": "string",
      "description": "Cached poster URL"
    }
  },
  "required": [
    "movie_id"
  ]
}