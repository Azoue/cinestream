{
  "name": "Category",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Category name"
    },
    "description": {
      "type": "string",
      "description": "Category description"
    }
  },
  "required": [
    "name"
  ]
}