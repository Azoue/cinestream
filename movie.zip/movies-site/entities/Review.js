{
  "name": "Review",
  "type": "object",
  "properties": {
    "movie_id": {
      "type": "string",
      "description": "Reference to the movie"
    },
    "rating": {
      "type": "number",
      "description": "Rating out of 10"
    },
    "comment": {
      "type": "string",
      "description": "Review text"
    },
    "reviewer_name": {
      "type": "string",
      "description": "Cached reviewer name"
    }
  },
  "required": [
    "movie_id",
    "rating"
  ]
}