{
  "name": "Movie",
  "type": "object",
  "properties": {
    "title": {
      "type": "string",
      "description": "Movie title"
    },
    "description": {
      "type": "string",
      "description": "Movie synopsis"
    },
    "genre": {
      "type": "array",
      "items": {
        "type": "string"
      },
      "description": "Movie genres"
    },
    "poster_url": {
      "type": "string",
      "description": "URL to movie poster image"
    },
    "background_image": {
      "type": "string",
      "description": "URL to cinematic background/banner image"
    },
    "video_url": {
      "type": "string",
      "description": "URL to the movie video file"
    },
    "trailer_url": {
      "type": "string",
      "description": "URL to the trailer video"
    },
    "release_year": {
      "type": "number",
      "description": "Year of release"
    },
    "rating": {
      "type": "number",
      "description": "Average rating out of 10"
    },
    "duration": {
      "type": "string",
      "description": "Duration like 2h 15m"
    },
    "director": {
      "type": "string",
      "description": "Director name"
    },
    "actors": {
      "type": "array",
      "items": {
        "type": "string"
      },
      "description": "List of actor names"
    },
    "content_type": {
      "type": "string",
      "enum": [
        "movie",
        "series"
      ],
      "default": "movie",
      "description": "Movie or TV Series"
    },
    "featured": {
      "type": "boolean",
      "default": false,
      "description": "Show in hero banner"
    },
    "trending": {
      "type": "boolean",
      "default": false,
      "description": "Show in trending section"
    },
    "view_count": {
      "type": "number",
      "default": 0,
      "description": "Total view count"
    },
    "category_id": {
      "type": "string",
      "description": "Category reference"
    },
    "maturity_rating": {
      "type": "string",
      "enum": [
        "G",
        "PG",
        "PG-13",
        "R",
        "NC-17"
      ],
      "default": "PG-13"
    },
    "seasons": {
      "type": "array",
      "description": "Seasons for TV series",
      "items": {
        "type": "object",
        "properties": {
          "season_number": {
            "type": "number"
          },
          "title": {
            "type": "string"
          },
          "episodes": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "episode_number": {
                  "type": "number"
                },
                "title": {
                  "type": "string"
                },
                "description": {
                  "type": "string"
                },
                "video_url": {
                  "type": "string"
                },
                "duration": {
                  "type": "string"
                },
                "thumbnail_url": {
                  "type": "string"
                }
              }
            }
          }
        }
      }
    }
  },
  "required": [
    "title"
  ]
}