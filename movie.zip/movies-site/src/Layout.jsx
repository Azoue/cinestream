import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Search, Bell, ChevronDown, User, LogOut, Heart, Clock, Film, LayoutDashboard, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const NAV_ITEMS = [
  { label: "Home", page: "Home" },
  { label: "Movies", page: "Browse", params: "?type=movie" },
  { label: "TV Shows", page: "Browse", params: "?type=series" },
  { label: "My List", page: "Favorites" },
];

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isFullscreen = currentPageName === "Watch";
  if (isFullscreen) return <>{children}</>;

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Navbar */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? "bg-[#0a0a0a]/95 backdrop-blur-md shadow-lg" : "bg-gradient-to-b from-black/80 to-transparent"
        }`}
      >
        <div className="flex items-center justify-between px-4 md:px-12 h-16">
          <div className="flex items-center gap-8">
            <Link to={createPageUrl("Home")} className="flex items-center gap-2">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69a9cfb8ff0a5745a6530071/520dae71a_screen-02.png" alt="CineStream" className="w-8 h-8 rounded-lg" />
              <span className="text-white font-extrabold text-xl tracking-tight hidden sm:block">
                Cine<span className="text-[#3b82f6]">Stream</span>
              </span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.label}
                  to={createPageUrl(item.page) + (item.params || "")}
                  className="text-sm text-gray-300 hover:text-white transition-colors font-medium"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to={createPageUrl("Search")}
              className="p-2 text-gray-300 hover:text-white transition-colors"
            >
              <Search className="w-5 h-5" />
            </Link>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowProfile(!showProfile)}
                  className="flex items-center gap-2 hover:opacity-80 transition-opacity"
                >
                  <div className="w-8 h-8 rounded bg-gradient-to-br from-[#e50914] to-[#b81d24] flex items-center justify-center text-white text-sm font-bold">
                    {(user.full_name || user.email || "U")[0].toUpperCase()}
                  </div>
                  <ChevronDown className="w-4 h-4 text-white hidden md:block" />
                </button>
                <AnimatePresence>
                  {showProfile && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute right-0 top-12 w-56 bg-[#141414] border border-white/10 rounded-lg shadow-2xl overflow-hidden"
                    >
                      <div className="p-4 border-b border-white/10">
                        <p className="text-white text-sm font-medium truncate">{user.full_name || "User"}</p>
                        <p className="text-gray-500 text-xs truncate">{user.email}</p>
                      </div>
                      <div className="py-2">
                        <Link to={createPageUrl("Profile")} onClick={() => setShowProfile(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
                          <User className="w-4 h-4" /> Profile
                        </Link>
                        <Link to={createPageUrl("Favorites")} onClick={() => setShowProfile(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
                          <Heart className="w-4 h-4" /> My List
                        </Link>
                        <Link to={createPageUrl("WatchHistoryPage")} onClick={() => setShowProfile(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
                          <Clock className="w-4 h-4" /> Watch History
                        </Link>
                        {user.role === "admin" && (
                          <Link to={createPageUrl("AdminDashboard")} onClick={() => setShowProfile(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
                            <LayoutDashboard className="w-4 h-4" /> Admin
                          </Link>
                        )}
                      </div>
                      <div className="border-t border-white/10 py-2">
                        <button
                          onClick={() => base44.auth.logout()}
                          className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors w-full"
                        >
                          <LogOut className="w-4 h-4" /> Sign Out
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                onClick={() => base44.auth.redirectToLogin()}
                className="bg-[#e50914] hover:bg-[#f6121d] text-white text-sm font-semibold px-5 py-1.5 rounded transition-colors"
              >
                Sign In
              </button>
            )}

            <button
              onClick={() => setMobileMenu(!mobileMenu)}
              className="md:hidden p-2 text-gray-300 hover:text-white"
            >
              {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileMenu && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-[#0a0a0a]/95 backdrop-blur-md border-t border-white/5 overflow-hidden"
            >
              <nav className="flex flex-col py-4">
                {NAV_ITEMS.map((item) => (
                  <Link
                    key={item.label}
                    to={createPageUrl(item.page) + (item.params || "")}
                    onClick={() => setMobileMenu(false)}
                    className="px-6 py-3 text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Page content */}
      <main className={currentPageName === "Home" ? "" : "pt-16"}>
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 mt-20 py-10 px-6 md:px-16">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-2 mb-6">
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69a9cfb8ff0a5745a6530071/520dae71a_screen-02.png" alt="CineStream" className="w-5 h-5 rounded" />
            <span className="text-white font-bold">Cine<span className="text-[#3b82f6]">Stream</span></span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-500">
            <div className="space-y-2">
              <Link to={createPageUrl("Home")} className="block hover:text-gray-300 transition-colors">Home</Link>
              <Link to={createPageUrl("Browse")} className="block hover:text-gray-300 transition-colors">Browse</Link>
            </div>
            <div className="space-y-2">
              <Link to={createPageUrl("Favorites")} className="block hover:text-gray-300 transition-colors">My List</Link>
              <Link to={createPageUrl("Profile")} className="block hover:text-gray-300 transition-colors">Account</Link>
            </div>
            <div className="space-y-2">
              <span className="block">Help Center</span>
              <span className="block">Terms of Use</span>
            </div>
            <div className="space-y-2">
              <span className="block">Privacy</span>
              <span className="block">Contact Us</span>
            </div>
          </div>
          <p className="text-gray-600 text-xs mt-8">© 2026 Streamflix. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}