import React, { useRef, useState } from "react";
import { Play, Download, Clock, Tv, ChevronLeft, ChevronRight } from "lucide-react";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function EpisodesCarousel({ episodes = [], movie, currentSeason }) {
  const scrollRef = useRef(null);
  const [canLeft, setCanLeft] = useState(false);
  const [canRight, setCanRight] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  const updateScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanLeft(scrollLeft > 10);
    setCanRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (dir) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir === "left" ? -600 : 600, behavior: "smooth" });
    setTimeout(updateScroll, 400);
  };

  const watchUrl = (ep) =>
    createPageUrl("Watch") +
    `?id=${movie.id}&season=${currentSeason?.season_number || 1}&episode=${ep.episode_number}&video=${encodeURIComponent(ep.video_url || "")}`;

  return (
    <div
      className="relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Left Arrow */}
      <motion.div
        animate={{ opacity: canLeft && isHovered ? 1 : 0 }}
        className="absolute left-0 top-0 bottom-0 z-20 flex items-center pointer-events-none"
        style={{ width: 60 }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a]/90 to-transparent" />
        <button
          onClick={() => scroll("left")}
          className="relative z-10 ml-1 w-10 h-10 rounded-full bg-black/80 hover:bg-[#e50914] border border-white/15 flex items-center justify-center text-white transition-all pointer-events-auto hover:scale-110 shadow-lg"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </motion.div>

      {/* Scrollable Row */}
      <div
        ref={scrollRef}
        onScroll={updateScroll}
        className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 pt-1"
      >
        {episodes.map((ep, ei) => (
          <motion.div
            key={ei}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: ei * 0.04 }}
            className="flex-shrink-0 w-[260px] sm:w-[300px] md:w-[320px] bg-[#141414] rounded-xl overflow-hidden border border-white/5 hover:border-white/25 transition-all group"
          >
            {/* Thumbnail */}
            <div className="relative aspect-video bg-[#1a1a1a] overflow-hidden">
              {ep.thumbnail_url ? (
                <img
                  src={ep.thumbnail_url}
                  alt={ep.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#1a1a2e] to-[#0a0a1a]">
                  <Tv className="w-10 h-10 text-gray-700" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

              {/* Play overlay on hover */}
              {ep.video_url && (
                <button
                  onClick={() => window.location.href = watchUrl(ep)}
                  className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                >
                  <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
                    <Play className="w-6 h-6 text-black fill-black ml-0.5" />
                  </div>
                </button>
              )}

              {/* Episode number badge */}
              <span className="absolute top-2 left-2 bg-black/70 backdrop-blur-sm text-white text-xs font-bold px-2 py-0.5 rounded">
                {ep.episode_number ? `ح ${ep.episode_number}` : `#${ei + 1}`}
              </span>

              {/* Duration badge */}
              {ep.duration && (
                <span className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-sm text-gray-300 text-xs px-2 py-0.5 rounded flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {ep.duration}
                </span>
              )}
            </div>

            {/* Info + Actions */}
            <div className="p-3">
              <h4 className="text-white font-semibold text-sm truncate mb-1">
                {ep.title || `الحلقة ${ei + 1}`}
              </h4>
              {ep.description && (
                <p className="text-gray-500 text-xs leading-relaxed line-clamp-2 mb-3">{ep.description}</p>
              )}
              {ep.video_url && (
                <div className="flex gap-2">
                  <button
                    onClick={() => window.location.href = watchUrl(ep)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-[#e50914] hover:bg-[#f6121d] text-white text-xs font-bold py-2 rounded-lg transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" /> مشاهدة
                  </button>
                  <a
                    href={ep.video_url}
                    download
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1 bg-white/10 hover:bg-white/20 text-gray-300 text-xs font-semibold px-3 py-2 rounded-lg transition-colors"
                    title="تحميل"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Right Arrow */}
      <motion.div
        animate={{ opacity: canRight && isHovered ? 1 : 0 }}
        className="absolute right-0 top-0 bottom-0 z-20 flex items-center justify-end pointer-events-none"
        style={{ width: 60 }}
      >
        <div className="absolute inset-0 bg-gradient-to-l from-[#0a0a0a]/90 to-transparent" />
        <button
          onClick={() => scroll("right")}
          className="relative z-10 mr-1 w-10 h-10 rounded-full bg-black/80 hover:bg-[#e50914] border border-white/15 flex items-center justify-center text-white transition-all pointer-events-auto hover:scale-110 shadow-lg"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </motion.div>
    </div>
  );
}