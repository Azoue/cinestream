import React, { useState, useEffect, useRef } from "react";
import { Play, Info, ChevronLeft, ChevronRight, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";

// Floating particle
function Particle({ style }) {
  return (
    <div
      className="float-dot absolute rounded-full pointer-events-none"
      style={style}
    />
  );
}

const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  id: i,
  style: {
    width: Math.random() * 4 + 1 + "px",
    height: Math.random() * 4 + 1 + "px",
    left: Math.random() * 100 + "%",
    top: Math.random() * 100 + "%",
    background: i % 3 === 0 ? "rgba(229,9,20,0.6)" : i % 3 === 1 ? "rgba(108,59,197,0.5)" : "rgba(255,255,255,0.3)",
    "--dur": (Math.random() * 5 + 4) + "s",
    animationDelay: (Math.random() * 4) + "s",
    filter: "blur(0.5px)",
  },
}));

export default function HeroBanner({ movies = [] }) {
  const [current, setCurrent] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const featured = movies.filter(m => m.featured);
  const items = featured.length > 0 ? featured : movies.slice(0, 5);

  useEffect(() => {
    if (items.length <= 1) return;
    const timer = setInterval(() => {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrent(prev => (prev + 1) % items.length);
        setIsTransitioning(false);
      }, 400);
    }, 8000);
    return () => clearInterval(timer);
  }, [items.length]);

  const goTo = (i) => {
    if (i === current) return;
    setIsTransitioning(true);
    setTimeout(() => { setCurrent(i); setIsTransitioning(false); }, 400);
  };

  if (items.length === 0) return null;
  const movie = items[current];

  return (
    <div className="relative w-full h-[80vh] md:h-[90vh] overflow-hidden">
      {/* Background layers */}
      <AnimatePresence mode="wait">
        <motion.div
          key={movie.id + "-bg"}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 1.0, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          {/* Main cinematic image */}
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url(${movie.background_image || movie.poster_url || "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&q=80"})`,
              transform: "scale(1.03)",
            }}
          />
          {/* Color tint based on index */}
          <div
            className="absolute inset-0"
            style={{
              background: [
                "linear-gradient(135deg, rgba(229,9,20,0.12) 0%, transparent 50%)",
                "linear-gradient(135deg, rgba(108,59,197,0.12) 0%, transparent 50%)",
                "linear-gradient(135deg, rgba(26,58,108,0.15) 0%, transparent 50%)",
                "linear-gradient(135deg, rgba(20,100,60,0.1) 0%, transparent 50%)",
                "linear-gradient(135deg, rgba(180,120,0,0.1) 0%, transparent 50%)",
              ][current % 5],
            }}
          />
          {/* Cinematic gradient overlays */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#080810] via-[#080810]/65 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080810] via-transparent to-[#080810]/25" />
          {/* Bottom blur feather */}
          <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-[#080810] to-transparent" />
        </motion.div>
      </AnimatePresence>

      {/* Floating particles */}
      {PARTICLES.map(p => <Particle key={p.id} style={p.style} />)}

      {/* Animated scan lines effect */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
        }}
      />

      {/* Content */}
      <div className="relative z-10 h-full flex items-end pb-28 md:pb-36 px-6 md:px-16 lg:px-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={movie.id + "-content"}
            initial={{ opacity: 0, x: -40, y: 20 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-2xl xl:max-w-3xl"
          >
            {/* Badge row */}
            <div className="flex items-center gap-2 mb-4">
              {movie.content_type === "series" && (
                <span className="px-3 py-1 text-xs font-bold bg-[#e50914] text-white rounded-sm tracking-widest uppercase">
                  Series
                </span>
              )}
              {movie.maturity_rating && (
                <span className="px-2 py-1 text-xs font-semibold border border-white/25 rounded bg-black/30 backdrop-blur-sm text-gray-300">
                  {movie.maturity_rating}
                </span>
              )}
              {movie.trending && (
                <span className="px-3 py-1 text-xs font-bold border border-yellow-500/40 rounded bg-yellow-500/10 text-yellow-400">
                  🔥 Trending
                </span>
              )}
            </div>

            {/* Title with animated underline */}
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-black text-white leading-none mb-4 tracking-tight drop-shadow-2xl">
              {movie.title}
            </h1>

            {/* Meta info */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex items-center flex-wrap gap-3 text-sm text-gray-300 mb-5"
            >
              {movie.release_year && (
                <span className="font-medium">{movie.release_year}</span>
              )}
              {movie.duration && (
                <>
                  <span className="w-1 h-1 rounded-full bg-gray-500" />
                  <span>{movie.duration}</span>
                </>
              )}
              {movie.rating && (
                <>
                  <span className="w-1 h-1 rounded-full bg-gray-500" />
                  <span className="flex items-center gap-1">
                    <span className="text-yellow-400">★</span>
                    <span className="text-[#46d369] font-bold">{movie.rating}</span>
                    <span className="text-gray-500">/10</span>
                  </span>
                </>
              )}
              {movie.genre?.length > 0 && (
                <>
                  <span className="w-1 h-1 rounded-full bg-gray-500" />
                  <span className="text-gray-400">{movie.genre.slice(0, 3).join(" · ")}</span>
                </>
              )}
            </motion.div>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-gray-300 text-sm md:text-base leading-relaxed mb-8 line-clamp-3 max-w-xl text-shadow"
              style={{ textShadow: "0 1px 8px rgba(0,0,0,0.8)" }}
            >
              {movie.description || "A captivating cinematic experience awaits you."}
            </motion.p>

            {/* Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex gap-3 flex-wrap"
            >
              <button
                onClick={() => window.location.href = createPageUrl("MovieDetail") + `?id=${movie.id}`}
                className="btn-glow flex items-center gap-2 bg-white hover:bg-white/90 text-black font-bold px-7 md:px-9 py-3 rounded-md text-base transition-all duration-200"
              >
                <Play className="w-5 h-5 fill-black" /> Play
              </button>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Thumbnail strip at bottom right */}
      {items.length > 1 && (
        <div className="absolute bottom-8 right-6 md:right-16 z-20 flex flex-col gap-2 items-end">
          <div className="flex gap-2 items-center">
            <button
              onClick={() => goTo(current === 0 ? items.length - 1 : current - 1)}
              className="p-1.5 rounded-full bg-black/40 hover:bg-black/70 border border-white/10 transition-colors text-white"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex gap-1.5">
              {items.map((_, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  className={`rounded-full transition-all duration-400 ${
                    i === current
                      ? "w-8 h-2 bg-[#e50914] shadow-[0_0_8px_rgba(229,9,20,0.7)]"
                      : "w-2 h-2 bg-white/30 hover:bg-white/60"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => goTo((current + 1) % items.length)}
              className="p-1.5 rounded-full bg-black/40 hover:bg-black/70 border border-white/10 transition-colors text-white"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Animated progress bar */}
      {items.length > 1 && (
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/5 z-20">
          <motion.div
            key={current}
            className="h-full bg-gradient-to-r from-[#e50914] to-[#ff6b35]"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 8, ease: "linear" }}
          />
        </div>
      )}
    </div>
  );
}