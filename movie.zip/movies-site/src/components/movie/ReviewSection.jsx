import React, { useState } from "react";
import { Star, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

function StarRating({ rating, onRate, interactive = false }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
        <button
          key={i}
          disabled={!interactive}
          onClick={() => onRate?.(i)}
          onMouseEnter={() => interactive && setHover(i)}
          onMouseLeave={() => interactive && setHover(0)}
          className="disabled:cursor-default"
        >
          <Star
            className={`w-4 h-4 transition-colors ${
              i <= (hover || rating)
                ? "text-yellow-400 fill-yellow-400"
                : "text-gray-600"
            }`}
          />
        </button>
      ))}
    </div>
  );
}

export default function ReviewSection({ reviews = [], onSubmit, isAuthenticated }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) return;
    setSubmitting(true);
    await onSubmit?.({ rating, comment });
    setRating(0);
    setComment("");
    setSubmitting(false);
  };

  return (
    <div className="mt-10">
      <h3 className="text-xl font-bold text-white mb-6">Reviews</h3>

      {isAuthenticated && (
        <div className="bg-[#1a1a1a] rounded-lg p-5 mb-6 border border-white/5">
          <p className="text-sm text-gray-400 mb-3">Rate this title</p>
          <StarRating rating={rating} onRate={setRating} interactive />
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Write your review..."
            className="mt-4 bg-[#141414] border-white/10 text-white placeholder:text-gray-500 resize-none"
            rows={3}
          />
          <Button
            onClick={handleSubmit}
            disabled={rating === 0 || submitting}
            className="mt-3 bg-[#e50914] hover:bg-[#f6121d] text-white"
          >
            <Send className="w-4 h-4 mr-2" />
            {submitting ? "Submitting..." : "Submit Review"}
          </Button>
        </div>
      )}

      <div className="space-y-4">
        {reviews.length === 0 && (
          <p className="text-gray-500 text-sm">No reviews yet. Be the first to review!</p>
        )}
        {reviews.map((review, i) => (
          <motion.div
            key={review.id || i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-[#141414] rounded-lg p-4 border border-white/5"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-white">
                {review.reviewer_name || "Anonymous"}
              </span>
              <StarRating rating={review.rating} />
            </div>
            {review.comment && (
              <p className="text-sm text-gray-400 leading-relaxed">{review.comment}</p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}