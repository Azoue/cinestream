import React, { useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import MovieCard from "./MovieCard";
import { motion } from "framer-motion";

export default function MovieCarousel({ movies = [], onAddFavorite, title }) {
  const scrollRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  const updateScrollState = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (dir) => {
    if (!scrollRef.current) return;
    const amount = scrollRef.current.clientWidth * 0.85;
    scrollRef.current.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
    setTimeout(updateScrollState, 400);
  };

  if (movies.length === 0) return null;

  return (
    <div
      className="relative mb-10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Left Arrow */}
      <motion.div
        initial={false}
        animate={{ opacity: canScrollLeft && isHovered ? 1 : 0, x: canScrollLeft && isHovered ? 0 : -8 }}
        transition={{ duration: 0.2 }}
        className="absolute left-0 top-0 bottom-4 z-20 flex items-center pointer-events-none"
        style={{ width: 70 }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#080810]/90 to-transparent" />
        <button
          onClick={() => scroll("left")}
          className="relative z-10 ml-2 w-10 h-10 md:w-12 md:h-12 rounded-full bg-black/80 hover:bg-[#e50914] border border-white/15 hover:border-[#e50914] flex items-center justify-center text-white transition-all duration-200 shadow-xl pointer-events-auto hover:scale-110"
        >
          <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
        </button>
      </motion.div>

      {/* Cards Row */}
      <div
        ref={scrollRef}
        onScroll={updateScrollState}
        className="flex gap-2 md:gap-3 lg:gap-4 overflow-x-auto hide-scrollbar px-6 md:px-16 pb-6 pt-3"
        style={{ scrollSnapType: "x mandatory" }}
      >
        {movies.map((movie, i) => (
          <motion.div
            key={movie.id}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "0px -100px 0px 0px" }}
            transition={{ delay: Math.min(i * 0.05, 0.5), duration: 0.35 }}
            style={{ scrollSnapAlign: "start" }}
          >
            <MovieCard movie={movie} onAddFavorite={onAddFavorite} />
          </motion.div>
        ))}
      </div>

      {/* Right Arrow */}
      <motion.div
        initial={false}
        animate={{ opacity: canScrollRight && isHovered ? 1 : 0, x: canScrollRight && isHovered ? 0 : 8 }}
        transition={{ duration: 0.2 }}
        className="absolute right-0 top-0 bottom-4 z-20 flex items-center justify-end pointer-events-none"
        style={{ width: 70 }}
      >
        <div className="absolute inset-0 bg-gradient-to-l from-[#080810]/90 to-transparent" />
        <button
          onClick={() => scroll("right")}
          className="relative z-10 mr-2 w-10 h-10 md:w-12 md:h-12 rounded-full bg-black/80 hover:bg-[#e50914] border border-white/15 hover:border-[#e50914] flex items-center justify-center text-white transition-all duration-200 shadow-xl pointer-events-auto hover:scale-110"
        >
          <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
        </button>
      </motion.div>
    </div>
  );
}