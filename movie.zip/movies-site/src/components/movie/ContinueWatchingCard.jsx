import React from "react";
import { Play } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function ContinueWatchingCard({ item }) {
  const progressPct = item.duration > 0 ? (item.progress / item.duration) * 100 : 0;

  return (
    <div
      onClick={() => window.location.href = createPageUrl("Watch") + `?id=${item.movie_id}`}
      className="flex-shrink-0 w-[160px] md:w-[200px] cursor-pointer group relative rounded-xl overflow-hidden"
    >
      <div className="relative" style={{ aspectRatio: "2/3" }}>
        <img
          src={item.movie_poster || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=600&q=80"}
          alt={item.movie_title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center">
            <Play className="w-6 h-6 text-black fill-black ml-0.5" />
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0">
        <div className="h-1 bg-gray-700">
          <div className="h-full bg-[#e50914]" style={{ width: `${progressPct}%` }} />
        </div>
        <div className="bg-[#1a1a1a]/90 backdrop-blur-sm p-2">
          <p className="text-sm font-medium text-white truncate">{item.movie_title}</p>
        </div>
      </div>
    </div>
  );
}