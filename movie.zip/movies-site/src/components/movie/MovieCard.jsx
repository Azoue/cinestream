import React, { useState } from "react";
import { Play, Plus, Star, Info } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";

export default function MovieCard({ movie, onAddFavorite }) {
  const [hovered, setHovered] = useState(false);

  const goToDetail = () => {
    window.location.href = createPageUrl("MovieDetail") + `?id=${movie.id}`;
  };

  const goToWatch = (e) => {
    e.stopPropagation();
    window.location.href = createPageUrl("Watch") + `?id=${movie.id}`;
  };

  return (
    <div
      className="relative flex-shrink-0 w-[130px] sm:w-[160px] md:w-[190px] lg:w-[220px]"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={goToDetail}
    >
      {/* Card */}
      <motion.div
        className="rounded-lg overflow-hidden cursor-pointer relative"
        animate={hovered ? { scale: 1.12, y: -10, zIndex: 30 } : { scale: 1, y: 0, zIndex: 1 }}
        transition={{ duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] }}
        style={{
          boxShadow: hovered
            ? "0 20px 60px rgba(0,0,0,0.85), 0 0 30px rgba(229,9,20,0.2)"
            : "0 4px 12px rgba(0,0,0,0.4)",
          transformOrigin: "center bottom",
          position: "relative",
          zIndex: hovered ? 30 : 1,
        }}
      >
        {/* Poster */}
        <div className="aspect-[2/3] bg-[#1a1a1a] overflow-hidden">
          <motion.img
            src={movie.poster_url || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&q=80"}
            alt={movie.title}
            className="w-full h-full object-cover"
            animate={hovered ? { scale: 1.08 } : { scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            loading="lazy"
          />
        </div>

        {/* Always-visible gradient + bottom info */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

        {/* Rating badge */}
        {movie.rating && (
          <div className="absolute top-2 left-2 flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-black/70 backdrop-blur-sm">
            <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400" />
            <span className="text-[10px] font-bold text-white">{movie.rating}</span>
          </div>
        )}

        {/* Series badge */}
        {movie.content_type === "series" && (
          <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-[#e50914] text-[8px] font-bold text-white uppercase tracking-wide">
            Series
          </div>
        )}

        {/* Hover Panel */}
        <AnimatePresence>
          {hovered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#141414] via-[#141414]/95 to-transparent pt-8 pb-3 px-3"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-white text-xs sm:text-sm font-bold leading-snug mb-2 line-clamp-2 drop-shadow">
                {movie.title}
              </h3>

              {/* Meta row */}
              <div className="flex items-center gap-1.5 mb-3 flex-wrap">
                {movie.release_year && (
                  <span className="text-[10px] text-[#46d369] font-semibold">{movie.release_year}</span>
                )}
                {movie.maturity_rating && (
                  <span className="px-1 border border-gray-600 text-[9px] text-gray-400 rounded">
                    {movie.maturity_rating}
                  </span>
                )}
                {movie.duration && (
                  <span className="text-[10px] text-gray-500">{movie.duration}</span>
                )}
              </div>

              {/* Genre tags */}
              {movie.genre?.length > 0 && (
                <div className="flex gap-1 flex-wrap mb-3">
                  {movie.genre.slice(0, 2).map((g) => (
                    <span key={g} className="text-[9px] text-gray-400 bg-white/10 px-1.5 py-0.5 rounded">
                      {g}
                    </span>
                  ))}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <motion.button
                  whileTap={{ scale: 0.88 }}
                  onClick={goToWatch}
                  className="flex-1 flex items-center justify-center gap-1 bg-white hover:bg-gray-100 text-black text-xs font-bold py-1.5 rounded-md transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-black" />
                  <span className="hidden sm:inline">تشغيل</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.88 }}
                  onClick={(e) => { e.stopPropagation(); onAddFavorite?.(movie); }}
                  className="w-8 h-7 rounded-md border border-gray-500 hover:border-white bg-transparent flex items-center justify-center text-white hover:bg-white/10 transition-all"
                  title="أضف للقائمة"
                >
                  <Plus className="w-3.5 h-3.5" />
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.88 }}
                  onClick={(e) => { e.stopPropagation(); goToDetail(); }}
                  className="w-8 h-7 rounded-md border border-gray-500 hover:border-white bg-transparent flex items-center justify-center text-white hover:bg-white/10 transition-all"
                  title="مزيد من المعلومات"
                >
                  <Info className="w-3.5 h-3.5" />
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}