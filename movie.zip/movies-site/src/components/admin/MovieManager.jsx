import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Search, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { motion } from "framer-motion";
import SeasonsEditor from "./SeasonsEditor";

const GENRES = ["Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Romance", "Thriller", "Animation", "Documentary", "Fantasy", "Adventure", "Crime"];

const EMPTY_MOVIE = {
  title: "", description: "", genre: [], poster_url: "", background_image: "",
  video_url: "", trailer_url: "", release_year: 2024, rating: 0, duration: "",
  director: "", actors: [], content_type: "movie", featured: false, trending: false,
  maturity_rating: "PG-13", category_id: "", seasons: [],
};

export default function MovieManager({ movies = [], categories = [] }) {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_MOVIE);
  const [genreInput, setGenreInput] = useState("");
  const [actorInput, setActorInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const filtered = movies.filter((m) =>
    m.title?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_MOVIE);
    setDialogOpen(true);
  };

  const openEdit = (movie) => {
    setEditing(movie);
    setForm({
      title: movie.title || "",
      description: movie.description || "",
      genre: movie.genre || [],
      poster_url: movie.poster_url || "",
      background_image: movie.background_image || "",
      video_url: movie.video_url || "",
      trailer_url: movie.trailer_url || "",
      release_year: movie.release_year || 2024,
      rating: movie.rating || 0,
      duration: movie.duration || "",
      director: movie.director || "",
      actors: movie.actors || [],
      content_type: movie.content_type || "movie",
      featured: movie.featured || false,
      trending: movie.trending || false,
      maturity_rating: movie.maturity_rating || "PG-13",
      category_id: movie.category_id || "",
      seasons: movie.seasons || [],
    });
    setDialogOpen(true);
  };

  const handleUpload = async (e, field) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((prev) => ({ ...prev, [field]: file_url }));
    setUploading(false);
  };

  const handleSave = async () => {
    if (editing) {
      await base44.entities.Movie.update(editing.id, form);
    } else {
      await base44.entities.Movie.create(form);
    }
    queryClient.invalidateQueries({ queryKey: ["adminMovies"] });
    setDialogOpen(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this movie?")) return;
    await base44.entities.Movie.delete(id);
    queryClient.invalidateQueries({ queryKey: ["adminMovies"] });
  };

  const addGenre = () => {
    if (genreInput && !form.genre.includes(genreInput)) {
      setForm((prev) => ({ ...prev, genre: [...prev.genre, genreInput] }));
    }
    setGenreInput("");
  };

  const addActor = () => {
    if (actorInput && !form.actors.includes(actorInput)) {
      setForm((prev) => ({ ...prev, actors: [...prev.actors, actorInput] }));
    }
    setActorInput("");
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search movies..."
            className="pl-10 bg-[#1a1a1a] border-white/10 text-white"
          />
        </div>
        <Button onClick={openCreate} className="bg-[#e50914] hover:bg-[#f6121d]">
          <Plus className="w-4 h-4 mr-2" /> Add Movie
        </Button>
      </div>

      <div className="space-y-2">
        {filtered.map((movie, i) => (
          <motion.div
            key={movie.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.02 }}
            className="flex items-center gap-4 bg-[#1a1a1a] rounded-lg p-3 border border-white/5 hover:bg-[#222] transition-colors"
          >
            <img
              src={movie.poster_url || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=80&q=80"}
              alt={movie.title}
              className="w-12 h-16 object-cover rounded"
            />
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">{movie.title}</p>
              <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                <span>{movie.content_type || "movie"}</span>
                <span>•</span>
                <span>{movie.release_year}</span>
                {movie.rating && <><span>•</span><span className="text-[#46d369]">★ {movie.rating}</span></>}
                <span>•</span>
                <span>{(movie.view_count || 0)} views</span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {movie.featured && <span className="px-2 py-0.5 text-[10px] bg-yellow-500/20 text-yellow-400 rounded">Featured</span>}
              {movie.trending && <span className="px-2 py-0.5 text-[10px] bg-[#e50914]/20 text-[#e50914] rounded">Trending</span>}
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => openEdit(movie)} className="text-gray-400 hover:text-white">
                <Pencil className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleDelete(movie.id)} className="text-gray-400 hover:text-[#e50914]">
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        ))}
        {filtered.length === 0 && (
          <p className="text-gray-500 text-center py-10">No movies found</p>
        )}
      </div>

      {/* Movie Form Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#141414] border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Movie" : "Add Movie"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-400 text-sm">Title</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Content Type</Label>
                <Select value={form.content_type} onValueChange={(v) => setForm({ ...form, content_type: v })}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="movie" className="text-white">Movie</SelectItem>
                    <SelectItem value="series" className="text-white">TV Series</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-gray-400 text-sm">Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-[#1a1a1a] border-white/10 text-white mt-1" rows={3} />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-gray-400 text-sm">Release Year</Label>
                <Input type="number" value={form.release_year} onChange={(e) => setForm({ ...form, release_year: parseInt(e.target.value) || 2024 })} className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Rating (0-10)</Label>
                <Input type="number" min="0" max="10" step="0.1" value={form.rating} onChange={(e) => setForm({ ...form, rating: parseFloat(e.target.value) || 0 })} className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Duration</Label>
                <Input value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} placeholder="2h 15m" className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
              </div>
            </div>

            <div>
              <Label className="text-gray-400 text-sm">Director</Label>
              <Input value={form.director} onChange={(e) => setForm({ ...form, director: e.target.value })} className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
            </div>

            {/* Genres */}
            <div>
              <Label className="text-gray-400 text-sm">Genres</Label>
              <div className="flex gap-2 mt-1">
                <Select value={genreInput} onValueChange={setGenreInput}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white flex-1"><SelectValue placeholder="Select genre" /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    {GENRES.map((g) => (<SelectItem key={g} value={g} className="text-white">{g}</SelectItem>))}
                  </SelectContent>
                </Select>
                <Button onClick={addGenre} variant="outline" className="border-white/10 text-white">Add</Button>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {form.genre.map((g) => (
                  <span key={g} className="px-2 py-1 bg-white/10 text-sm rounded flex items-center gap-1">
                    {g}
                    <button onClick={() => setForm({ ...form, genre: form.genre.filter((x) => x !== g) })} className="text-gray-400 hover:text-white">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Actors */}
            <div>
              <Label className="text-gray-400 text-sm">Actors</Label>
              <div className="flex gap-2 mt-1">
                <Input value={actorInput} onChange={(e) => setActorInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addActor()} placeholder="Actor name" className="bg-[#1a1a1a] border-white/10 text-white" />
                <Button onClick={addActor} variant="outline" className="border-white/10 text-white">Add</Button>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {form.actors.map((a) => (
                  <span key={a} className="px-2 py-1 bg-white/10 text-sm rounded flex items-center gap-1">
                    {a}
                    <button onClick={() => setForm({ ...form, actors: form.actors.filter((x) => x !== a) })} className="text-gray-400 hover:text-white">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Media uploads */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-400 text-sm">Poster</Label>
                <div className="mt-1">
                  <Input value={form.poster_url} onChange={(e) => setForm({ ...form, poster_url: e.target.value })} placeholder="URL or upload" className="bg-[#1a1a1a] border-white/10 text-white mb-2" />
                  <label className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] border border-white/10 rounded-md cursor-pointer hover:bg-[#222] transition-colors text-sm text-gray-400">
                    <Upload className="w-4 h-4" /> Upload poster
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUpload(e, "poster_url")} />
                  </label>
                </div>
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Background Image</Label>
                <div className="mt-1">
                  <Input value={form.background_image} onChange={(e) => setForm({ ...form, background_image: e.target.value })} placeholder="URL or upload" className="bg-[#1a1a1a] border-white/10 text-white mb-2" />
                  <label className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] border border-white/10 rounded-md cursor-pointer hover:bg-[#222] transition-colors text-sm text-gray-400">
                    <Upload className="w-4 h-4" /> Upload background
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUpload(e, "background_image")} />
                  </label>
                </div>
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Video URL</Label>
                <div className="mt-1">
                  <Input value={form.video_url} onChange={(e) => setForm({ ...form, video_url: e.target.value })} placeholder="Video URL or upload" className="bg-[#1a1a1a] border-white/10 text-white mb-2" />
                  <label className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] border border-white/10 rounded-md cursor-pointer hover:bg-[#222] transition-colors text-sm text-gray-400">
                    <Upload className="w-4 h-4" /> Upload video
                    <input type="file" accept="video/*" className="hidden" onChange={(e) => handleUpload(e, "video_url")} />
                  </label>
                </div>
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Trailer URL</Label>
                <Input value={form.trailer_url} onChange={(e) => setForm({ ...form, trailer_url: e.target.value })} placeholder="Trailer URL" className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
              </div>
            </div>

            {/* Category & Maturity */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-400 text-sm">Category</Label>
                <Select value={form.category_id} onValueChange={(v) => setForm({ ...form, category_id: v })}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white mt-1"><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    {categories.map((c) => (<SelectItem key={c.id} value={c.id} className="text-white">{c.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-gray-400 text-sm">Maturity Rating</Label>
                <Select value={form.maturity_rating} onValueChange={(v) => setForm({ ...form, maturity_rating: v })}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    {["G", "PG", "PG-13", "R", "NC-17"].map((r) => (<SelectItem key={r} value={r} className="text-white">{r}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Seasons (series only) */}
            {form.content_type === "series" && (
              <div className="border-t border-white/10 pt-4">
                <SeasonsEditor seasons={form.seasons || []} onChange={(s) => setForm({ ...form, seasons: s })} />
              </div>
            )}

            {/* Toggles */}
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={form.featured} onCheckedChange={(v) => setForm({ ...form, featured: v })} />
                <Label className="text-gray-400 text-sm">Featured</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.trending} onCheckedChange={(v) => setForm({ ...form, trending: v })} />
                <Label className="text-gray-400 text-sm">Trending</Label>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-white/5">
              <Button variant="ghost" onClick={() => setDialogOpen(false)} className="text-gray-400">Cancel</Button>
              <Button onClick={handleSave} disabled={!form.title || uploading} className="bg-[#e50914] hover:bg-[#f6121d]">
                {uploading ? "Uploading..." : editing ? "Save Changes" : "Add Movie"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}