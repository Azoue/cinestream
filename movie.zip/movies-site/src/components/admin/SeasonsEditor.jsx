import React, { useState } from "react";
import { Plus, Trash2, ChevronDown, ChevronRight, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";

export default function SeasonsEditor({ seasons = [], onChange }) {
  const [openSeasons, setOpenSeasons] = useState({});
  const [uploading, setUploading] = useState(null);

  const toggleSeason = (i) => setOpenSeasons((prev) => ({ ...prev, [i]: !prev[i] }));

  const addSeason = () => {
    const newSeasons = [...seasons, { season_number: seasons.length + 1, title: `الموسم ${seasons.length + 1}`, episodes: [] }];
    onChange(newSeasons);
    setOpenSeasons((prev) => ({ ...prev, [newSeasons.length - 1]: true }));
  };

  const removeSeason = (si) => {
    onChange(seasons.filter((_, i) => i !== si));
  };

  const updateSeason = (si, field, value) => {
    const updated = [...seasons];
    updated[si] = { ...updated[si], [field]: value };
    onChange(updated);
  };

  const addEpisode = (si) => {
    const updated = [...seasons];
    const eps = updated[si].episodes || [];
    updated[si] = { ...updated[si], episodes: [...eps, { episode_number: eps.length + 1, title: `الحلقة ${eps.length + 1}`, description: "", video_url: "", duration: "", thumbnail_url: "" }] };
    onChange(updated);
  };

  const removeEpisode = (si, ei) => {
    const updated = [...seasons];
    updated[si] = { ...updated[si], episodes: updated[si].episodes.filter((_, i) => i !== ei) };
    onChange(updated);
  };

  const updateEpisode = (si, ei, field, value) => {
    const updated = [...seasons];
    const eps = [...(updated[si].episodes || [])];
    eps[ei] = { ...eps[ei], [field]: value };
    updated[si] = { ...updated[si], episodes: eps };
    onChange(updated);
  };

  const handleUpload = async (e, si, ei, field) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(`${si}-${ei}-${field}`);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    updateEpisode(si, ei, field, file_url);
    setUploading(null);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-gray-300 text-sm font-semibold">المواسم والحلقات</Label>
        <Button onClick={addSeason} size="sm" className="bg-blue-600 hover:bg-blue-700 text-white text-xs">
          <Plus className="w-3 h-3 mr-1" /> إضافة موسم
        </Button>
      </div>

      {seasons.length === 0 && (
        <p className="text-gray-600 text-sm text-center py-4 border border-white/5 rounded-lg">لا توجد مواسم بعد. اضغط "إضافة موسم" للبدء.</p>
      )}

      {seasons.map((season, si) => (
        <div key={si} className="border border-white/10 rounded-lg overflow-hidden">
          {/* Season Header */}
          <div className="flex items-center gap-2 bg-[#222] px-4 py-3">
            <button onClick={() => toggleSeason(si)} className="text-gray-400 hover:text-white">
              {openSeasons[si] ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            <span className="text-xs text-gray-500 w-6">{si + 1}</span>
            <Input
              value={season.title || `الموسم ${si + 1}`}
              onChange={(e) => updateSeason(si, "title", e.target.value)}
              className="bg-transparent border-0 text-white font-medium text-sm p-0 h-auto focus-visible:ring-0 flex-1"
            />
            <span className="text-xs text-gray-500">{(season.episodes || []).length} حلقة</span>
            <button onClick={() => removeSeason(si)} className="text-gray-600 hover:text-red-500 ml-1">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Episodes */}
          {openSeasons[si] && (
            <div className="p-4 space-y-3 bg-[#1a1a1a]">
              {(season.episodes || []).map((ep, ei) => (
                <div key={ei} className="bg-[#111] rounded-lg p-3 border border-white/5">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-[#e50914]">الحلقة {ei + 1}</span>
                    <button onClick={() => removeEpisode(si, ei)} className="text-gray-600 hover:text-red-500">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <Label className="text-gray-500 text-xs">اسم الحلقة</Label>
                      <Input value={ep.title || ""} onChange={(e) => updateEpisode(si, ei, "title", e.target.value)} className="bg-[#1a1a1a] border-white/10 text-white mt-1 text-sm" />
                    </div>
                    <div>
                      <Label className="text-gray-500 text-xs">المدة</Label>
                      <Input value={ep.duration || ""} onChange={(e) => updateEpisode(si, ei, "duration", e.target.value)} placeholder="45m" className="bg-[#1a1a1a] border-white/10 text-white mt-1 text-sm" />
                    </div>
                  </div>
                  <div className="mb-2">
                    <Label className="text-gray-500 text-xs">الوصف</Label>
                    <Textarea value={ep.description || ""} onChange={(e) => updateEpisode(si, ei, "description", e.target.value)} className="bg-[#1a1a1a] border-white/10 text-white mt-1 text-sm" rows={2} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-gray-500 text-xs">رابط الفيديو</Label>
                      <Input value={ep.video_url || ""} onChange={(e) => updateEpisode(si, ei, "video_url", e.target.value)} placeholder="URL" className="bg-[#1a1a1a] border-white/10 text-white mt-1 text-sm mb-1" />
                      <label className="flex items-center gap-1 px-2 py-1.5 bg-[#1a1a1a] border border-white/10 rounded cursor-pointer hover:bg-[#222] text-xs text-gray-500">
                        <Upload className="w-3 h-3" />
                        {uploading === `${si}-${ei}-video_url` ? "جارٍ الرفع..." : "رفع فيديو"}
                        <input type="file" accept="video/*" className="hidden" onChange={(e) => handleUpload(e, si, ei, "video_url")} />
                      </label>
                    </div>
                    <div>
                      <Label className="text-gray-500 text-xs">صورة مصغرة</Label>
                      <Input value={ep.thumbnail_url || ""} onChange={(e) => updateEpisode(si, ei, "thumbnail_url", e.target.value)} placeholder="URL" className="bg-[#1a1a1a] border-white/10 text-white mt-1 text-sm mb-1" />
                      <label className="flex items-center gap-1 px-2 py-1.5 bg-[#1a1a1a] border border-white/10 rounded cursor-pointer hover:bg-[#222] text-xs text-gray-500">
                        <Upload className="w-3 h-3" />
                        {uploading === `${si}-${ei}-thumbnail_url` ? "جارٍ الرفع..." : "رفع صورة"}
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUpload(e, si, ei, "thumbnail_url")} />
                      </label>
                    </div>
                  </div>
                </div>
              ))}
              <Button onClick={() => addEpisode(si)} size="sm" variant="outline" className="border-white/10 text-gray-400 hover:text-white w-full text-xs">
                <Plus className="w-3 h-3 mr-1" /> إضافة حلقة
              </Button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}