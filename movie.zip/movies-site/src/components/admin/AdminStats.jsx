import React from "react";
import { Film, Users, Eye, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function AdminStats({ movies = [], users = [], watchHistory = [] }) {
  const totalViews = movies.reduce((sum, m) => sum + (m.view_count || 0), 0);
  const topMovies = [...movies].sort((a, b) => (b.view_count || 0) - (a.view_count || 0)).slice(0, 5);

  const stats = [
    { icon: Film, label: "Total Movies", value: movies.length, color: "from-[#e50914] to-[#b81d24]" },
    { icon: Users, label: "Total Users", value: users.length, color: "from-blue-500 to-blue-700" },
    { icon: Eye, label: "Total Views", value: totalViews.toLocaleString(), color: "from-emerald-500 to-emerald-700" },
    { icon: TrendingUp, label: "Active Watchers", value: watchHistory.length.toLocaleString(), color: "from-purple-500 to-purple-700" },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-[#1a1a1a] rounded-xl p-5 border border-white/5"
          >
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {topMovies.length > 0 && (
        <div className="bg-[#1a1a1a] rounded-xl p-5 border border-white/5">
          <h3 className="text-lg font-bold text-white mb-4">Most Watched</h3>
          <div className="space-y-3">
            {topMovies.map((m, i) => (
              <div key={m.id} className="flex items-center gap-3">
                <span className="text-lg font-bold text-gray-600 w-6">{i + 1}</span>
                <img
                  src={m.poster_url || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=100&q=80"}
                  alt={m.title}
                  className="w-10 h-14 object-cover rounded"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{m.title}</p>
                  <p className="text-gray-500 text-xs">{(m.view_count || 0).toLocaleString()} views</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}