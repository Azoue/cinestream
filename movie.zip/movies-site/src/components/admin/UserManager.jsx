import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Search, Shield, ShieldAlert, Trash2, UserPlus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";

export default function UserManager({ users = [] }) {
  const [search, setSearch] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("user");
  const queryClient = useQueryClient();

  const filtered = users.filter(
    (u) =>
      u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const handleRoleChange = async (user, newRole) => {
    await base44.entities.User.update(user.id, { role: newRole });
    queryClient.invalidateQueries({ queryKey: ["adminUsers"] });
  };

  const handleDelete = async (id) => {
    if (!confirm("Remove this user?")) return;
    await base44.entities.User.delete(id);
    queryClient.invalidateQueries({ queryKey: ["adminUsers"] });
  };

  const handleInvite = async () => {
    if (!inviteEmail) return;
    await base44.users.inviteUser(inviteEmail, inviteRole);
    setInviteEmail("");
    setInviteOpen(false);
    queryClient.invalidateQueries({ queryKey: ["adminUsers"] });
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users..."
            className="pl-10 bg-[#1a1a1a] border-white/10 text-white"
          />
        </div>
        <Button onClick={() => setInviteOpen(true)} className="bg-[#e50914] hover:bg-[#f6121d]">
          <UserPlus className="w-4 h-4 mr-2" /> Invite User
        </Button>
      </div>

      <div className="space-y-2">
        {filtered.map((user, i) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.02 }}
            className="flex items-center gap-4 bg-[#1a1a1a] rounded-lg p-4 border border-white/5 hover:bg-[#222] transition-colors"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center text-white font-bold text-sm">
              {(user.full_name || user.email || "U")[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">{user.full_name || "No Name"}</p>
              <p className="text-gray-500 text-sm truncate">{user.email}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={user.role === "admin" ? "bg-[#e50914]/20 text-[#e50914] border-[#e50914]/30" : "bg-blue-500/20 text-blue-400 border-blue-500/30"}>
                {user.role === "admin" ? <ShieldAlert className="w-3 h-3 mr-1" /> : <Shield className="w-3 h-3 mr-1" />}
                {user.role || "user"}
              </Badge>
              <Select value={user.role || "user"} onValueChange={(v) => handleRoleChange(user, v)}>
                <SelectTrigger className="w-24 bg-[#1a1a1a] border-white/10 text-white text-xs h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1a1a] border-white/10">
                  <SelectItem value="user" className="text-white">User</SelectItem>
                  <SelectItem value="admin" className="text-white">Admin</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="ghost" size="icon" onClick={() => handleDelete(user.id)} className="text-gray-400 hover:text-[#e50914]">
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        ))}
        {filtered.length === 0 && (
          <p className="text-gray-500 text-center py-10">No users found</p>
        )}
      </div>

      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="bg-[#141414] border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Invite User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-400 text-sm">Email</Label>
              <Input value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="user@example.com" className="bg-[#1a1a1a] border-white/10 text-white mt-1" />
            </div>
            <div>
              <Label className="text-gray-400 text-sm">Role</Label>
              <Select value={inviteRole} onValueChange={setInviteRole}>
                <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white mt-1"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-[#1a1a1a] border-white/10">
                  <SelectItem value="user" className="text-white">User</SelectItem>
                  <SelectItem value="admin" className="text-white">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <Button variant="ghost" onClick={() => setInviteOpen(false)} className="text-gray-400">Cancel</Button>
              <Button onClick={handleInvite} disabled={!inviteEmail} className="bg-[#e50914] hover:bg-[#f6121d]">Send Invite</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}