import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

export default function CategoryManager({ categories = [] }) {
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");
  const queryClient = useQueryClient();

  const handleCreate = async () => {
    if (!newName.trim()) return;
    await base44.entities.Category.create({ name: newName.trim() });
    setNewName("");
    queryClient.invalidateQueries({ queryKey: ["adminCategories"] });
  };

  const handleUpdate = async (id) => {
    if (!editName.trim()) return;
    await base44.entities.Category.update(id, { name: editName.trim() });
    setEditingId(null);
    queryClient.invalidateQueries({ queryKey: ["adminCategories"] });
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this category?")) return;
    await base44.entities.Category.delete(id);
    queryClient.invalidateQueries({ queryKey: ["adminCategories"] });
  };

  return (
    <div>
      <div className="flex gap-2 mb-6">
        <Input
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleCreate()}
          placeholder="New category name..."
          className="bg-[#1a1a1a] border-white/10 text-white max-w-sm"
        />
        <Button onClick={handleCreate} disabled={!newName.trim()} className="bg-[#e50914] hover:bg-[#f6121d]">
          <Plus className="w-4 h-4 mr-2" /> Add
        </Button>
      </div>

      <div className="space-y-2">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.02 }}
            className="flex items-center gap-4 bg-[#1a1a1a] rounded-lg p-4 border border-white/5"
          >
            {editingId === cat.id ? (
              <>
                <Input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleUpdate(cat.id)}
                  className="bg-[#141414] border-white/10 text-white flex-1"
                  autoFocus
                />
                <Button variant="ghost" size="icon" onClick={() => handleUpdate(cat.id)} className="text-[#46d369]">
                  <Check className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => setEditingId(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <>
                <p className="text-white font-medium flex-1">{cat.name}</p>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setEditingId(cat.id);
                    setEditName(cat.name);
                  }}
                  className="text-gray-400 hover:text-white"
                >
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(cat.id)} className="text-gray-400 hover:text-[#e50914]">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </>
            )}
          </motion.div>
        ))}
        {categories.length === 0 && (
          <p className="text-gray-500 text-center py-10">No categories yet</p>
        )}
      </div>
    </div>
  );
}