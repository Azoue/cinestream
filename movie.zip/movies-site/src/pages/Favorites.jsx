import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart, Trash2 } from "lucide-react";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Favorites() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: favorites = [], isLoading } = useQuery({
    queryKey: ["favorites"],
    queryFn: () => base44.entities.Favorite.list("-created_date", 200),
    enabled: !!user,
  });

  const removeFavorite = async (id) => {
    await base44.entities.Favorite.delete(id);
    queryClient.invalidateQueries({ queryKey: ["favorites"] });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen px-6 md:px-16 py-8">
      <h1 className="text-3xl md:text-4xl font-extrabold text-white mb-8 flex items-center gap-3">
        <Heart className="w-8 h-8 text-[#e50914]" /> My List
      </h1>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-10 h-10 border-2 border-[#e50914] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : favorites.length === 0 ? (
        <div className="text-center py-20">
          <Heart className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Your list is empty</p>
          <p className="text-gray-600 text-sm mt-2">Add movies and shows to your list to see them here</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {favorites.map((fav, i) => (
            <motion.div
              key={fav.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className="relative group"
            >
              <div
                onClick={() => window.location.href = createPageUrl("MovieDetail") + `?id=${fav.movie_id}`}
                className="movie-card rounded-md overflow-hidden cursor-pointer aspect-[2/3]"
              >
                <img
                  src={fav.movie_poster || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&q=80"}
                  alt={fav.movie_title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-white text-sm font-bold truncate">{fav.movie_title}</p>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeFavorite(fav.id);
                }}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-black/60 text-gray-400 hover:text-[#e50914] opacity-0 group-hover:opacity-100 transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}