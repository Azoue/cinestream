import React, { useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import MovieCarousel from "@/components/movie/MovieCarousel";

export default function Browse() {
  const params = new URLSearchParams(window.location.search);
  const contentType = params.get("type");

  const { data: movies = [] } = useQuery({
    queryKey: ["browseMovies"],
    queryFn: () => base44.entities.Movie.list("-created_date", 200),
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list("-created_date", 50),
  });

  const filtered = useMemo(() => {
    if (!contentType) return movies;
    return movies.filter((m) => m.content_type === contentType || (!m.content_type && contentType === "movie"));
  }, [movies, contentType]);

  const addFavorite = async (movie) => {
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) { base44.auth.redirectToLogin(); return; }
    await base44.entities.Favorite.create({
      movie_id: movie.id,
      movie_title: movie.title,
      movie_poster: movie.poster_url,
    });
  };

  // Group by genre
  const genreGroups = useMemo(() => {
    const groups = {};
    filtered.forEach((m) => {
      (m.genre || ["Uncategorized"]).forEach((g) => {
        if (!groups[g]) groups[g] = [];
        groups[g].push(m);
      });
    });
    return groups;
  }, [filtered]);

  return (
    <div className="min-h-screen py-8">
      <div className="px-6 md:px-16 mb-8">
        <h1 className="text-3xl md:text-4xl font-extrabold text-white">
          {contentType === "series" ? "TV Shows" : contentType === "movie" ? "Movies" : "Browse All"}
        </h1>
      </div>

      {Object.entries(genreGroups).map(([genre, genreMovies]) => (
        <MovieCarousel
          key={genre}
          title={genre}
          movies={genreMovies}
          onAddFavorite={addFavorite}
        />
      ))}

      {filtered.length === 0 && (
        <div className="text-center py-20">
          <p className="text-gray-500 text-lg">No content available yet</p>
        </div>
      )}
    </div>
  );
}