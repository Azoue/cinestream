import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Play, Heart, ThumbsUp, Share2, AlertCircle, Star, Film, Check, Download, Tv, ChevronLeft, Search, Menu } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import MovieCarousel from "@/components/movie/MovieCarousel";
import ReviewSection from "@/components/movie/ReviewSection";

export default function MovieDetail() {
  const params = new URLSearchParams(window.location.search);
  const movieId = params.get("id");
  const queryClient = useQueryClient();
  const [currentUser, setCurrentUser] = useState(null);
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState(0);
  const [showFullDesc, setShowFullDesc] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: movie, isLoading } = useQuery({
    queryKey: ["movie", movieId],
    queryFn: () => base44.entities.Movie.filter({ id: movieId }),
    select: (data) => data[0],
    enabled: !!movieId,
  });

  const { data: allMovies = [] } = useQuery({
    queryKey: ["allMovies"],
    queryFn: () => base44.entities.Movie.list("-created_date", 50),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews", movieId],
    queryFn: () => base44.entities.Review.filter({ movie_id: movieId }, "-created_date", 20),
    enabled: !!movieId,
  });

  const { data: favorites = [] } = useQuery({
    queryKey: ["myFavorites"],
    queryFn: () => base44.entities.Favorite.list("-created_date", 200),
    enabled: !!currentUser,
  });

  useEffect(() => {
    if (favorites.length > 0 && movieId) {
      setIsFavorite(favorites.some((f) => f.movie_id === movieId));
    }
  }, [favorites, movieId]);

  const addFavorite = async () => {
    if (!currentUser) { base44.auth.redirectToLogin(); return; }
    if (isFavorite) return;
    await base44.entities.Favorite.create({ movie_id: movie.id, movie_title: movie.title, movie_poster: movie.poster_url });
    setIsFavorite(true);
    queryClient.invalidateQueries({ queryKey: ["myFavorites"] });
  };

  const submitReview = async ({ rating, comment }) => {
    await base44.entities.Review.create({ movie_id: movieId, rating, comment, reviewer_name: currentUser?.full_name || "Anonymous" });
    queryClient.invalidateQueries({ queryKey: ["reviews", movieId] });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <div className="w-10 h-10 border-2 border-[#e50914] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!movie) {
    return <div className="min-h-screen flex items-center justify-center text-gray-400 bg-[#0a0a0a]">لم يتم العثور على المحتوى</div>;
  }

  const isSeries = movie.content_type === "series";
  const seasons = movie.seasons || [];
  const currentSeason = seasons[selectedSeason];
  const episodes = currentSeason?.episodes || [];
  const totalEpisodes = seasons.reduce((acc, s) => acc + (s.episodes?.length || 0), 0);

  const recommended = allMovies
    .filter((m) => m.id !== movieId && m.genre?.some((g) => movie.genre?.includes(g)))
    .slice(0, 15);

  const ratingStars = movie.rating ? Math.round((movie.rating / 10) * 5) : 0;

  return (
    <div className="min-h-screen bg-[#080810] text-white" dir="rtl">

      {/* ===== HERO SECTION ===== */}
      <div className="relative w-full" style={{ height: "100vw", maxHeight: "500px", minHeight: "320px" }}>
        {/* Background image */}
        <img
          src={movie.background_image || movie.poster_url || "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&q=80"}
          alt={movie.title}
          className="w-full h-full object-cover object-top"
        />

        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/10 to-[#080810]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent" />

        {/* ===== TOP NAV BAR (floating over image) ===== */}
        <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-4 pt-10 pb-3">
          {/* Back */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => window.history.back()}
            className="w-9 h-9 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-lg"
          >
            <ChevronLeft className="w-5 h-5" />
          </motion.button>

          {/* Right icons */}
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => window.location.href = createPageUrl("Search")}
              className="w-9 h-9 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-lg"
            >
              <Search className="w-4 h-4" />
            </motion.button>
            {currentUser && (
              <div className="w-9 h-9 rounded-full bg-[#e50914] flex items-center justify-center text-white font-bold text-sm shadow-lg border-2 border-white/20">
                {(currentUser.full_name || currentUser.email || "U")[0].toUpperCase()}
              </div>
            )}
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="w-9 h-9 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-lg"
            >
              <Menu className="w-4 h-4" />
            </motion.button>
          </div>
        </div>

        {/* Center play button on hero */}
        {(isSeries ? episodes.length > 0 : !!movie.video_url) && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <motion.button
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                const url = isSeries
                  ? createPageUrl("Watch") + `?id=${movie.id}&season=${currentSeason?.season_number || 1}&episode=${episodes[0]?.episode_number}&video=${encodeURIComponent(episodes[0]?.video_url || "")}`
                  : createPageUrl("Watch") + `?id=${movie.id}`;
                window.location.href = url;
              }}
              className="pointer-events-auto w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white/50 flex items-center justify-center shadow-2xl hover:bg-white/30 transition-all"
            >
              <Play className="w-7 h-7 fill-white text-white ml-1" />
            </motion.button>
          </div>
        )}
      </div>

      {/* ===== MAIN CONTENT ===== */}
      <div className="px-4 -mt-2 pb-10">

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl font-extrabold text-white mb-2 leading-tight"
        >
          {movie.title}
        </motion.h1>

        {/* Stars + rating */}
        {movie.rating && (
          <div className="flex items-center gap-2 mb-3">
            <div className="flex gap-0.5">
              {Array.from({ length: 5 }, (_, i) => (
                <Star key={i} className={`w-4 h-4 ${i < ratingStars ? "fill-yellow-400 text-yellow-400" : "text-gray-700 fill-gray-700"}`} />
              ))}
            </div>
            <span className="text-yellow-400 font-bold text-sm">{movie.rating}</span>
          </div>
        )}

        {/* Meta pills */}
        <div className="flex flex-wrap items-center gap-2 mb-5">
          {isSeries && totalEpisodes > 0 && (
            <span className="px-3 py-1 bg-[#e50914] rounded-lg text-xs text-white font-bold">{totalEpisodes} حلقة</span>
          )}
          {movie.duration && !isSeries && (
            <span className="px-3 py-1 bg-[#e50914] rounded-lg text-xs text-white font-bold">{movie.duration}</span>
          )}
          {movie.release_year && (
            <span className="px-3 py-1 bg-white/10 rounded-lg text-xs text-gray-200 font-medium border border-white/10">{movie.release_year}</span>
          )}
          {movie.maturity_rating && (
            <span className="px-3 py-1 bg-white/10 rounded-lg text-xs text-gray-200 font-medium border border-white/10">{movie.maturity_rating}</span>
          )}
          {movie.genre?.slice(0, 2).map((g) => (
            <span key={g} className="px-3 py-1 bg-white/10 rounded-lg text-xs text-gray-300 border border-white/10">{g}</span>
          ))}
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-4" />

        {/* Action icons */}
        <div className="flex items-center justify-around py-3 mb-5">
          <motion.button whileTap={{ scale: 0.85 }} onClick={addFavorite} className="flex flex-col items-center gap-1.5">
            <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${isFavorite ? "bg-[#e50914]" : "bg-white/10 border border-white/15"}`}>
              <Heart className={`w-5 h-5 ${isFavorite ? "fill-white text-white" : "text-gray-300"}`} />
            </div>
            <span className="text-[10px] text-gray-400">{isFavorite ? "محفوظ" : "المفضلة"}</span>
          </motion.button>

          <motion.button whileTap={{ scale: 0.85 }} className="flex flex-col items-center gap-1.5">
            <div className="w-11 h-11 rounded-full bg-white/10 border border-white/15 flex items-center justify-center">
              <ThumbsUp className="w-5 h-5 text-gray-300" />
            </div>
            <span className="text-[10px] text-gray-400">أعجبني</span>
          </motion.button>

          <motion.button whileTap={{ scale: 0.85 }} className="flex flex-col items-center gap-1.5">
            <div className="w-11 h-11 rounded-full bg-white/10 border border-white/15 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-gray-300" />
            </div>
            <span className="text-[10px] text-gray-400">إبلاغ</span>
          </motion.button>

          <motion.button whileTap={{ scale: 0.85 }} className="flex flex-col items-center gap-1.5">
            <div className="w-11 h-11 rounded-full bg-white/10 border border-white/15 flex items-center justify-center">
              <Share2 className="w-5 h-5 text-gray-300" />
            </div>
            <span className="text-[10px] text-gray-400">مشاركة</span>
          </motion.button>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-5" />

        {/* Description */}
        <div className="mb-5">
          <p className={`text-gray-300 text-sm leading-loose transition-all ${showFullDesc ? "" : "line-clamp-4"}`}>
            {movie.description || "لا يوجد وصف."}
          </p>
          {movie.description && movie.description.length > 200 && (
            <button onClick={() => setShowFullDesc(!showFullDesc)} className="text-[#e50914] text-xs mt-1 font-semibold">
              {showFullDesc ? "أقل" : "المزيد"}
            </button>
          )}
          {movie.director && (
            <p className="text-sm mt-3">
              <span className="text-gray-500">إخراج: </span>
              <span className="text-gray-200 font-medium">{movie.director}</span>
            </p>
          )}
          {movie.actors?.length > 0 && (
            <p className="text-sm mt-1">
              <span className="text-gray-500">طاقم العمل: </span>
              <span className="text-gray-200">{movie.actors.join("، ")}</span>
            </p>
          )}
        </div>

        {/* Trailer button */}
        {movie.trailer_url && (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => window.open(movie.trailer_url, "_blank")}
            className="w-full flex items-center justify-center gap-2 bg-white/8 hover:bg-white/14 text-white font-semibold py-3.5 rounded-2xl mb-4 transition-colors border border-white/12 backdrop-blur-sm"
          >
            <Film className="w-4 h-4 text-[#e50914]" /> مشاهدة الإعلان
          </motion.button>
        )}

        {/* Watch now button for movies */}
        {!isSeries && movie.video_url && (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => window.location.href = createPageUrl("Watch") + `?id=${movie.id}`}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-[#e50914] to-[#c0070f] text-white font-bold py-4 rounded-2xl mb-6 transition-colors text-base shadow-lg shadow-[#e50914]/30"
          >
            <Play className="w-5 h-5 fill-white" /> مشاهدة الآن
          </motion.button>
        )}

        {/* ===== SEASONS & EPISODES ===== */}
        {isSeries && seasons.length > 0 && (
          <div className="mt-2">
            {/* Season selector */}
            {seasons.length > 1 && (
              <div className="flex gap-2 mb-5 overflow-x-auto hide-scrollbar pb-1">
                {seasons.map((season, si) => (
                  <button
                    key={si}
                    onClick={() => setSelectedSeason(si)}
                    className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                      selectedSeason === si
                        ? "bg-[#e50914] text-white shadow-lg shadow-[#e50914]/30"
                        : "bg-white/8 text-gray-400 hover:bg-white/15 hover:text-white border border-white/10"
                    }`}
                  >
                    {season.title || `الموسم ${season.season_number || si + 1}`}
                  </button>
                ))}
              </div>
            )}

            {/* Season title */}
            <h2 className="text-white text-base font-bold mb-4 flex items-center gap-2">
              <span className="w-1 h-4 bg-[#e50914] rounded-full inline-block" />
              حلقات {currentSeason?.title || `الموسم ${currentSeason?.season_number || 1}`}
            </h2>

            {/* Episodes list */}
            {episodes.length > 0 ? (
              <div className="flex flex-col gap-3">
                {episodes.map((ep, ei) => (
                  <motion.div
                    key={ei}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: ei * 0.04 }}
                    className="flex items-center gap-3 bg-white/5 rounded-2xl overflow-hidden border border-white/8 hover:border-[#e50914]/40 hover:bg-white/8 transition-all group cursor-pointer"
                    onClick={() => ep.video_url && (window.location.href = createPageUrl("Watch") + `?id=${movie.id}&season=${currentSeason?.season_number || 1}&episode=${ep.episode_number}&video=${encodeURIComponent(ep.video_url)}`)}
                  >
                    {/* Thumbnail */}
                    <div className="relative flex-shrink-0 w-[100px] h-[65px] bg-[#111] overflow-hidden rounded-r-2xl">
                      {ep.thumbnail_url ? (
                        <img src={ep.thumbnail_url} alt={ep.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#1a1a2e] to-[#0a0a1a]">
                          <Tv className="w-6 h-6 text-gray-700" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-7 h-7 rounded-full bg-white/90 flex items-center justify-center">
                          <Play className="w-3 h-3 fill-black text-black ml-0.5" />
                        </div>
                      </div>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0 py-3">
                      <p className="text-[#e50914] text-[10px] font-bold mb-0.5 uppercase tracking-wide">
                        ح {ep.episode_number || ei + 1}
                      </p>
                      <h4 className="text-white font-semibold text-sm truncate leading-tight">
                        {ep.title || `الحلقة ${ei + 1}`}
                      </h4>
                      {ep.duration && (
                        <p className="text-gray-500 text-[10px] mt-0.5">{ep.duration}</p>
                      )}
                    </div>

                    {/* Download */}
                    {ep.video_url && (
                      <a
                        href={ep.video_url}
                        download
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="flex-shrink-0 ml-1 mr-3 p-2 rounded-xl bg-white/8 hover:bg-[#e50914]/20 text-gray-400 hover:text-[#e50914] transition-colors"
                        title="تحميل"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                    )}
                  </motion.div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 text-sm py-6 text-center">لا توجد حلقات في هذا الموسم بعد.</p>
            )}
          </div>
        )}

        {/* Reviews */}
        <div className="mt-10">
          <ReviewSection reviews={reviews} onSubmit={submitReview} isAuthenticated={!!currentUser} />
        </div>

        {/* Recommended */}
        {recommended.length > 0 && (
          <div className="mt-10">
            <MovieCarousel title="مشابه لهذا" movies={recommended} onAddFavorite={addFavorite} />
          </div>
        )}
      </div>
    </div>
  );
}