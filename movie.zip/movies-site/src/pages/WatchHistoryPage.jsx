import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock, Play, Trash2 } from "lucide-react";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function WatchHistoryPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: history = [], isLoading } = useQuery({
    queryKey: ["watchHistoryFull"],
    queryFn: () => base44.entities.WatchHistory.list("-updated_date", 200),
    enabled: !!user,
  });

  const removeItem = async (id) => {
    await base44.entities.WatchHistory.delete(id);
    queryClient.invalidateQueries({ queryKey: ["watchHistoryFull"] });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen px-6 md:px-16 py-8">
      <h1 className="text-3xl md:text-4xl font-extrabold text-white mb-8 flex items-center gap-3">
        <Clock className="w-8 h-8 text-blue-400" /> Watch History
      </h1>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-10 h-10 border-2 border-[#e50914] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : history.length === 0 ? (
        <div className="text-center py-20">
          <Clock className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">No watch history yet</p>
          <p className="text-gray-600 text-sm mt-2">Start watching to see your history here</p>
        </div>
      ) : (
        <div className="space-y-3">
          {history.map((item, i) => {
            const progressPct = item.duration > 0 ? (item.progress / item.duration) * 100 : 0;
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="flex items-center gap-4 bg-[#1a1a1a] rounded-lg p-3 border border-white/5 group hover:bg-[#222] transition-colors"
              >
                <div
                  onClick={() => window.location.href = createPageUrl("Watch") + `?id=${item.movie_id}`}
                  className="relative flex-shrink-0 w-40 aspect-video rounded overflow-hidden cursor-pointer"
                >
                  <img
                    src={item.movie_poster || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&q=80"}
                    alt={item.movie_title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-8 h-8 text-white fill-white" />
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
                    <div className="h-full bg-[#e50914]" style={{ width: `${progressPct}%` }} />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{item.movie_title || "Unknown"}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    {item.completed ? (
                      <span className="text-[#46d369]">Completed</span>
                    ) : (
                      `${Math.round(progressPct)}% watched`
                    )}
                  </p>
                </div>
                <button
                  onClick={() => removeItem(item.id)}
                  className="p-2 text-gray-600 hover:text-[#e50914] transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}