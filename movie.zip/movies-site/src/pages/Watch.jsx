import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import VideoPlayer from "@/components/movie/VideoPlayer";

export default function Watch() {
  const params = new URLSearchParams(window.location.search);
  const movieId = params.get("id");
  const episodeVideoUrl = params.get("video") ? decodeURIComponent(params.get("video")) : null;
  const seasonNum = params.get("season");
  const episodeNum = params.get("episode");
  const [user, setUser] = useState(null);
  const [watchRecord, setWatchRecord] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: movie } = useQuery({
    queryKey: ["watchMovie", movieId],
    queryFn: () => base44.entities.Movie.filter({ id: movieId }),
    select: (d) => d[0],
    enabled: !!movieId,
  });

  // Load existing watch history
  useEffect(() => {
    if (!user || !movieId) return;
    base44.entities.WatchHistory.filter({ movie_id: movieId })
      .then((records) => {
        const mine = records.find((r) => r.created_by === user.email);
        if (mine) setWatchRecord(mine);
      })
      .catch(() => {});
  }, [user, movieId]);

  // Increment view count
  useEffect(() => {
    if (!movie) return;
    base44.entities.Movie.update(movie.id, { view_count: (movie.view_count || 0) + 1 }).catch(() => {});
  }, [movie?.id]);

  const handleProgress = useCallback(
    async (currentTime, duration) => {
      if (!user || !movie) return;
      // Only save every 10 seconds
      if (Math.floor(currentTime) % 10 !== 0) return;

      const data = {
        movie_id: movie.id,
        movie_title: movie.title,
        movie_poster: movie.poster_url || movie.background_image,
        progress: Math.floor(currentTime),
        duration: Math.floor(duration),
        completed: currentTime >= duration - 10,
      };

      if (watchRecord) {
        await base44.entities.WatchHistory.update(watchRecord.id, data);
      } else {
        const created = await base44.entities.WatchHistory.create(data);
        setWatchRecord(created);
      }
    },
    [user, movie, watchRecord]
  );

  return (
    <div className="h-screen w-screen bg-black">
      <VideoPlayer
        videoUrl={episodeVideoUrl || movie?.video_url}
        title={movie?.title ? (episodeNum ? `${movie.title} - س${seasonNum} ح${episodeNum}` : movie.title) : "Loading..."}
        initialProgress={watchRecord?.progress || 0}
        onProgress={handleProgress}
        onBack={() => window.history.back()}
      />
    </div>
  );
}