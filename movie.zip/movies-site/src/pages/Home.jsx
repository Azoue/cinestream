import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import HeroBanner from "@/components/movie/HeroBanner";
import MovieCarousel from "@/components/movie/MovieCarousel";
import ContinueWatchingCard from "@/components/movie/ContinueWatchingCard";
import { motion, useInView } from "framer-motion";
import { Flame, Star, Clapperboard, Clock, Tv, Sparkles } from "lucide-react";

function SectionHeader({ icon: IconComp, title, color = "#e50914" }) {
  const Icon = IconComp;
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -20 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5 }}
      className="flex items-center gap-3 mb-5 px-6 md:px-16"
    >
      <div
        className="p-1.5 rounded-md"
        style={{ background: `${color}22`, border: `1px solid ${color}33` }}
      >
        <Icon className="w-4 h-4" style={{ color }} />
      </div>
      <h2 className="text-lg md:text-xl font-bold text-white section-title">{title}</h2>
    </motion.div>
  );
}

function GenrePill({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium border transition-all duration-200 ${
        active
          ? "bg-[#e50914] border-[#e50914] text-white shadow-[0_0_12px_rgba(229,9,20,0.4)]"
          : "bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white hover:border-white/20"
      }`}
    >
      {label}
    </button>
  );
}

const GENRES = ["All", "Action", "Drama", "Comedy", "Sci-Fi", "Horror", "Romance", "Thriller", "Fantasy"];

export default function Home() {
  const [user, setUser] = useState(null);
  const [activeGenre, setActiveGenre] = useState("All");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: movies = [] } = useQuery({
    queryKey: ["movies"],
    queryFn: () => base44.entities.Movie.list("-created_date", 100),
  });

  const { data: watchHistory = [] } = useQuery({
    queryKey: ["watchHistory"],
    queryFn: () => base44.entities.WatchHistory.filter({ completed: false }, "-updated_date", 10),
    enabled: !!user,
  });

  const addFavorite = async (movie) => {
    if (!user) { base44.auth.redirectToLogin(); return; }
    await base44.entities.Favorite.create({
      movie_id: movie.id,
      movie_title: movie.title,
      movie_poster: movie.poster_url,
    });
  };

  const filteredMovies = activeGenre === "All"
    ? movies
    : movies.filter(m => Array.isArray(m.genre) && m.genre.some(g => g.toLowerCase() === activeGenre.toLowerCase()));

  const trending = (activeGenre === "All" ? movies : filteredMovies).filter(m => m.trending);
  const movieList = filteredMovies.filter(m => m.content_type === "movie" || !m.content_type);
  const series = filteredMovies.filter(m => m.content_type === "series");
  const topRated = [...filteredMovies].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 20);
  const recentlyAdded = [...(activeGenre === "All" ? movies : filteredMovies)].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 20);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <HeroBanner movies={movies} />

      {/* Genre filter bar */}
      <div className="relative z-10 mt-6 mb-8 px-6 md:px-16">
        <div className="flex gap-2 overflow-x-auto hide-scrollbar py-3">
          {GENRES.map(g => (
            <GenrePill key={g} label={g} active={activeGenre === g} onClick={() => setActiveGenre(g)} />
          ))}
        </div>
      </div>



      {/* Trending */}
      {(trending.length > 0 || activeGenre === "All") && (
        <>
          <div className="mb-2">
            <SectionHeader icon={Flame} title="Trending Now" color="#e50914" />
            <MovieCarousel movies={trending.length > 0 ? trending : movies.slice(0, 15)} onAddFavorite={addFavorite} />
          </div>
          <div className="section-divider mx-6 md:mx-16" />
        </>
      )}

      {/* Popular Movies */}
      {movieList.length > 0 && (
        <div className="mb-2">
          <SectionHeader icon={Clapperboard} title="Popular Movies" color="#f59e0b" />
          <MovieCarousel movies={movieList.slice(0, 20)} onAddFavorite={addFavorite} />
        </div>
      )}

      {/* TV Series */}
      {series.length > 0 && (
        <>
          <div className="section-divider mx-6 md:mx-16" />
          <div className="mb-2">
            <SectionHeader icon={Tv} title="TV Series" color="#8b5cf6" />
            <MovieCarousel movies={series} onAddFavorite={addFavorite} />
          </div>
        </>
      )}

      {/* Top Rated */}
      {topRated.length > 0 && (
        <>
          <div className="section-divider mx-6 md:mx-16" />
          <div className="mb-2">
            <SectionHeader icon={Star} title="Top Rated" color="#46d369" />
            <MovieCarousel movies={topRated} onAddFavorite={addFavorite} />
          </div>
        </>
      )}

      {/* Recently Added */}
      {recentlyAdded.length > 0 && (
        <>
          <div className="section-divider mx-6 md:mx-16" />
          <div className="mb-2">
            <SectionHeader icon={Sparkles} title="Recently Added" color="#06b6d4" />
            <MovieCarousel movies={recentlyAdded} onAddFavorite={addFavorite} />
          </div>
        </>
      )}

      {/* Empty state */}
      {filteredMovies.length === 0 && (
        <div className="text-center py-24 text-gray-500">
          <p className="text-lg">No {activeGenre} content yet</p>
        </div>
      )}

      {/* Bottom spacer */}
      <div className="h-16" />
    </div>
  );
}