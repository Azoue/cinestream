import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { User, Mail, Shield, Clock, Heart, Film, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function Profile() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: favorites = [] } = useQuery({
    queryKey: ["profileFavorites"],
    queryFn: () => base44.entities.Favorite.list("-created_date", 200),
    enabled: !!user,
  });

  const { data: watchHistory = [] } = useQuery({
    queryKey: ["profileHistory"],
    queryFn: () => base44.entities.WatchHistory.list("-updated_date", 200),
    enabled: !!user,
  });

  if (!user) return null;

  const stats = [
    { icon: Heart, label: "My List", value: favorites.length, color: "text-[#e50914]", page: "Favorites" },
    { icon: Clock, label: "Watch History", value: watchHistory.length, color: "text-blue-400", page: "WatchHistoryPage" },
    { icon: Film, label: "Completed", value: watchHistory.filter(w => w.completed).length, color: "text-[#46d369]" },
  ];

  return (
    <div className="min-h-screen px-6 md:px-16 py-8 max-w-4xl mx-auto">
      {/* Profile header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row items-center gap-6 mb-10"
      >
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#e50914] to-[#b81d24] flex items-center justify-center text-white text-4xl font-bold shadow-2xl">
          {(user.full_name || user.email || "U")[0].toUpperCase()}
        </div>
        <div className="text-center md:text-left">
          <h1 className="text-3xl font-extrabold text-white">{user.full_name || "User"}</h1>
          <div className="flex flex-col md:flex-row items-center gap-3 mt-2 text-sm text-gray-400">
            <span className="flex items-center gap-1">
              <Mail className="w-4 h-4" /> {user.email}
            </span>
            <span className="flex items-center gap-1">
              <Shield className="w-4 h-4" />
              {user.role === "admin" ? "Administrator" : "Member"}
            </span>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-10">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => stat.page && (window.location.href = createPageUrl(stat.page))}
            className={`bg-[#1a1a1a] rounded-xl p-5 border border-white/5 text-center ${stat.page ? "cursor-pointer hover:bg-[#222] transition-colors" : ""}`}
          >
            <stat.icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent favorites */}
      {favorites.length > 0 && (
        <div className="mb-10">
          <h2 className="text-xl font-bold text-white mb-4">Recently Added to My List</h2>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-4">
            {favorites.slice(0, 10).map((fav) => (
              <div
                key={fav.id}
                onClick={() => window.location.href = createPageUrl("MovieDetail") + `?id=${fav.movie_id}`}
                className="flex-shrink-0 w-32 cursor-pointer"
              >
                <img
                  src={fav.movie_poster || "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=200&q=80"}
                  alt={fav.movie_title}
                  className="w-full aspect-[2/3] object-cover rounded-md movie-card"
                />
                <p className="text-xs text-gray-400 mt-2 truncate">{fav.movie_title}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="border-t border-white/5 pt-6">
        <Button
          onClick={() => base44.auth.logout()}
          variant="ghost"
          className="text-gray-400 hover:text-[#e50914] hover:bg-white/5"
        >
          <LogOut className="w-4 h-4 mr-2" /> Sign Out
        </Button>
      </div>
    </div>
  );
}