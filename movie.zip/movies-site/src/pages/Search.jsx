import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Search as SearchIcon, X, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import MovieCard from "@/components/movie/MovieCard";

const GENRES = ["Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Romance", "Thriller", "Animation", "Documentary", "Fantasy", "Adventure", "Crime"];
const YEARS = Array.from({ length: 30 }, (_, i) => 2026 - i);

export default function Search() {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("all");
  const [year, setYear] = useState("all");
  const [rating, setRating] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  const { data: movies = [] } = useQuery({
    queryKey: ["allMoviesSearch"],
    queryFn: () => base44.entities.Movie.list("-created_date", 200),
  });

  const filtered = useMemo(() => {
    return movies.filter((m) => {
      if (query && !m.title?.toLowerCase().includes(query.toLowerCase())) return false;
      if (genre !== "all" && !m.genre?.includes(genre)) return false;
      if (year !== "all" && m.release_year !== parseInt(year)) return false;
      if (rating !== "all") {
        const minRating = parseInt(rating);
        if ((m.rating || 0) < minRating) return false;
      }
      return true;
    });
  }, [movies, query, genre, year, rating]);

  const addFavorite = async (movie) => {
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) { base44.auth.redirectToLogin(); return; }
    await base44.entities.Favorite.create({
      movie_id: movie.id,
      movie_title: movie.title,
      movie_poster: movie.poster_url,
    });
  };

  return (
    <div className="min-h-screen px-6 md:px-16 py-8">
      {/* Search bar */}
      <div className="max-w-3xl mx-auto mb-8">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search movies and TV shows..."
            className="w-full pl-12 pr-12 py-4 bg-[#1a1a1a] border-white/10 text-white text-lg placeholder:text-gray-500 rounded-lg focus:border-[#e50914] focus:ring-[#e50914]"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 mt-4 text-sm text-gray-400 hover:text-white transition-colors"
        >
          <SlidersHorizontal className="w-4 h-4" />
          {showFilters ? "Hide Filters" : "Show Filters"}
        </button>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <Select value={genre} onValueChange={setGenre}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white">
                    <SelectValue placeholder="Genre" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="all" className="text-white">All Genres</SelectItem>
                    {GENRES.map((g) => (
                      <SelectItem key={g} value={g} className="text-white">{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={year} onValueChange={setYear}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white">
                    <SelectValue placeholder="Year" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="all" className="text-white">All Years</SelectItem>
                    {YEARS.map((y) => (
                      <SelectItem key={y} value={String(y)} className="text-white">{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={rating} onValueChange={setRating}>
                  <SelectTrigger className="bg-[#1a1a1a] border-white/10 text-white">
                    <SelectValue placeholder="Rating" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="all" className="text-white">All Ratings</SelectItem>
                    <SelectItem value="9" className="text-white">9+ Rating</SelectItem>
                    <SelectItem value="8" className="text-white">8+ Rating</SelectItem>
                    <SelectItem value="7" className="text-white">7+ Rating</SelectItem>
                    <SelectItem value="6" className="text-white">6+ Rating</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Results */}
      {query || genre !== "all" || year !== "all" || rating !== "all" ? (
        <div>
          <p className="text-gray-400 text-sm mb-6">
            {filtered.length} result{filtered.length !== 1 ? "s" : ""} found
          </p>
          <div className="flex flex-wrap gap-3">
            {filtered.map((movie) => (
              <MovieCard key={movie.id} movie={movie} onAddFavorite={addFavorite} />
            ))}
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">No results found</p>
              <p className="text-gray-600 text-sm mt-2">Try a different search term or filter</p>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-20">
          <SearchIcon className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Search for movies and TV shows</p>
          <p className="text-gray-600 text-sm mt-2">Use filters to narrow your results</p>
        </div>
      )}
    </div>
  );
}