import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, Film, Users, FolderOpen } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import AdminStats from "@/components/admin/AdminStats";
import MovieManager from "@/components/admin/MovieManager";
import UserManager from "@/components/admin/UserManager";
import CategoryManager from "@/components/admin/CategoryManager";

export default function AdminDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== "admin") {
        window.location.href = "/";
        return;
      }
      setUser(u);
    }).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: movies = [] } = useQuery({
    queryKey: ["adminMovies"],
    queryFn: () => base44.entities.Movie.list("-created_date", 500),
    enabled: !!user,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["adminUsers"],
    queryFn: () => base44.entities.User.list("-created_date", 500),
    enabled: !!user && user.role === "admin",
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["adminCategories"],
    queryFn: () => base44.entities.Category.list("-created_date", 100),
    enabled: !!user,
  });

  const { data: watchHistory = [] } = useQuery({
    queryKey: ["adminWatchHistory"],
    queryFn: () => base44.entities.WatchHistory.list("-created_date", 500),
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-[#e50914] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen px-6 md:px-16 py-8">
      <h1 className="text-3xl md:text-4xl font-extrabold text-white mb-2">Admin Dashboard</h1>
      <p className="text-gray-500 text-sm mb-8">Manage your streaming platform</p>

      <Tabs defaultValue="stats">
        <TabsList className="bg-[#1a1a1a] border border-white/5 mb-8">
          <TabsTrigger value="stats" className="data-[state=active]:bg-[#e50914] data-[state=active]:text-white">
            <BarChart3 className="w-4 h-4 mr-2" /> Statistics
          </TabsTrigger>
          <TabsTrigger value="movies" className="data-[state=active]:bg-[#e50914] data-[state=active]:text-white">
            <Film className="w-4 h-4 mr-2" /> Movies
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-[#e50914] data-[state=active]:text-white">
            <Users className="w-4 h-4 mr-2" /> Users
          </TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-[#e50914] data-[state=active]:text-white">
            <FolderOpen className="w-4 h-4 mr-2" /> Categories
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stats">
          <AdminStats movies={movies} users={users} watchHistory={watchHistory} />
        </TabsContent>
        <TabsContent value="movies">
          <MovieManager movies={movies} categories={categories} />
        </TabsContent>
        <TabsContent value="users">
          <UserManager users={users} />
        </TabsContent>
        <TabsContent value="categories">
          <CategoryManager categories={categories} />
        </TabsContent>
      </Tabs>
    </div>
  );
}